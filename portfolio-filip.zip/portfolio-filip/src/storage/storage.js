import AsyncStorage from '@react-native-async-storage/async-storage';

const PROJECTS_KEY = '@portfolio_projects';

const DEFAULT_PROJECTS = [
  {
    id: '1',
    title: 'HabitMate',
    description:
      'Aplikacja mobilna do śledzenia nawyków zaprojektowana w Figmie. Minimalistyczny design z fioletową paletą kolorów. Aplikacja umożliwia codzienne śledzenie nawyków, wyświetlanie serii oraz szczegółowych statystyk postępu.',
    technologies: ['Figma', 'UI/UX Design', 'Prototypowanie', 'iOS HIG'],
    category: 'Mobile Design',
    year: '2026',
    status: 'Zakończony',
    github: '',
    imageColor: '#5B56D0',
  },
  {
    id: '2',
    title: 'Biblioteka Miejska',
    description:
      'Projekt interfejsu użytkownika dla systemu zarządzania biblioteką miejską. Aplikacja umożliwia przeglądanie katalogu książek, rezerwację pozycji oraz zarządzanie kontem czytelnika. Design skupiony na prostocie i dostępności.',
    technologies: ['Figma', 'UI/UX Design', 'User Research', 'Wireframing'],
    category: 'UI/UX Design',
    year: '2025',
    status: 'Zakończony',
    github: '',
    imageColor: '#1A9E75',
  },
];

export const getProjects = async () => {
  try {
    const json = await AsyncStorage.getItem(PROJECTS_KEY);
    if (json !== null) {
      return JSON.parse(json);
    }
    await AsyncStorage.setItem(PROJECTS_KEY, JSON.stringify(DEFAULT_PROJECTS));
    return DEFAULT_PROJECTS;
  } catch (e) {
    console.error('Error loading projects:', e);
    return DEFAULT_PROJECTS;
  }
};

export const saveProjects = async (projects) => {
  try {
    await AsyncStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  } catch (e) {
    console.error('Error saving projects:', e);
  }
};

export const addProject = async (project) => {
  const projects = await getProjects();
  const newProject = { ...project, id: Date.now().toString() };
  const updated = [...projects, newProject];
  await saveProjects(updated);
  return updated;
};

export const deleteProject = async (id) => {
  const projects = await getProjects();
  const updated = projects.filter((p) => p.id !== id);
  await saveProjects(updated);
  return updated;
};
