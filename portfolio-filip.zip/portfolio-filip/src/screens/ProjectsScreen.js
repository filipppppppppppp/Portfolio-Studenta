import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { COLORS } from '../theme/colors';
import { getProjects } from '../storage/storage';

export default function ProjectsScreen({ navigation }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      (async () => {
        setLoading(true);
        const data = await getProjects();
        if (active) {
          setProjects(data);
          setLoading(false);
        }
      })();
      return () => { active = false; };
    }, [])
  );

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate('ProjectDetail', { project: item })}
      activeOpacity={0.85}
    >
      <View style={[styles.accent, { backgroundColor: item.imageColor || COLORS.primary }]} />
      <View style={styles.cardBody}>
        <View style={styles.cardTop}>
          <View style={[styles.dot, { backgroundColor: item.imageColor || COLORS.primary }]} />
          <Text style={styles.cardCategory}>{item.category}</Text>
          <Text style={styles.cardYear}>{item.year}</Text>
        </View>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardDesc} numberOfLines={2}>{item.description}</Text>
        <View style={styles.techRow}>
          {item.technologies.slice(0, 3).map((tech, i) => (
            <View key={i} style={styles.techChip}>
              <Text style={styles.techText}>{tech}</Text>
            </View>
          ))}
          {item.technologies.length > 3 && (
            <View style={styles.techChip}>
              <Text style={styles.techText}>+{item.technologies.length - 3}</Text>
            </View>
          )}
        </View>
        <View style={styles.statusRow}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: item.status === 'Zakończony' ? COLORS.success : COLORS.primary },
            ]}
          />
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={projects}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>📁</Text>
            <Text style={styles.emptyTitle}>Brak projektów</Text>
            <Text style={styles.emptyDesc}>
              Naciśnij + aby dodać swój pierwszy projekt
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('AddProject')}
        activeOpacity={0.85}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.background },
  list: { padding: 16, paddingBottom: 96 },

  card: {
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    borderRadius: 16,
    marginBottom: 14,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  accent: { width: 5 },
  cardBody: { flex: 1, padding: 16 },
  cardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  cardCategory: { flex: 1, fontSize: 12, color: COLORS.secondary },
  cardYear: { fontSize: 12, color: COLORS.textLight },
  cardTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  cardDesc: { fontSize: 13, color: COLORS.secondary, lineHeight: 19, marginBottom: 10 },
  techRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  techChip: {
    backgroundColor: COLORS.primaryLight,
    borderRadius: 7,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  techText: { fontSize: 11, color: COLORS.primary, fontWeight: '500' },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statusDot: { width: 7, height: 7, borderRadius: 3.5 },
  statusText: { fontSize: 12, color: COLORS.secondary },

  empty: { alignItems: 'center', paddingTop: 100 },
  emptyIcon: { fontSize: 52, marginBottom: 14 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  emptyDesc: { fontSize: 14, color: COLORS.textLight, textAlign: 'center' },

  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.primary,
    shadowOpacity: 0.45,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 5 },
    elevation: 7,
  },
  fabText: { fontSize: 32, color: COLORS.white, lineHeight: 36, fontWeight: '300' },
});
