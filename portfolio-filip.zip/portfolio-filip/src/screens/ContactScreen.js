import React from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, Clipboard, Linking,
} from 'react-native';
import { COLORS } from '../theme/colors';

const CONTACTS = [
  {
    icon: '✉️',
    label: 'Email',
    value: 'filip.nocon@interia.pl',
    url: 'mailto:filip.nocon@interia.pl',
    hint: 'Napisz wiadomość',
  },
  {
    icon: '🐙',
    label: 'GitHub',
    value: 'github.com/filipppppppppppp',
    url: 'https://github.com/filipppppppppppp',
    hint: 'Zobacz profil',
  },
];

export default function ContactScreen() {
  const handlePress = async (item) => {
    try {
      const supported = await Linking.canOpenURL(item.url);
      if (supported) {
        await Linking.openURL(item.url);
      } else {
        copyToClipboard(item);
      }
    } catch {
      copyToClipboard(item);
    }
  };

  const copyToClipboard = (item) => {
    Clipboard.setString(item.value);
    Alert.alert('Skopiowano!', `${item.value} zostało skopiowane do schowka.`);
  };

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 40 }}
    >
      <View style={styles.header}>
        <View style={styles.headerIconWrap}>
          <Text style={styles.headerIconText}>✉️</Text>
        </View>
        <Text style={styles.headerTitle}>Kontakt</Text>
        <Text style={styles.headerSubtitle}>
          Chętnie odpiszę na każdą wiadomość.{'\n'}Skontaktuj się ze mną!
        </Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Dane kontaktowe</Text>
        {CONTACTS.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.contactCard}
            onPress={() => handlePress(item)}
            activeOpacity={0.82}
          >
            <View style={styles.contactIconWrap}>
              <Text style={styles.contactIcon}>{item.icon}</Text>
            </View>
            <View style={styles.contactInfo}>
              <Text style={styles.contactLabel}>{item.label}</Text>
              <Text style={styles.contactValue}>{item.value}</Text>
              <Text style={styles.contactHint}>{item.hint} →</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Skopiuj dane</Text>
        {CONTACTS.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.copyBtn}
            onPress={() => copyToClipboard(item)}
            activeOpacity={0.8}
          >
            <Text style={styles.copyBtnText}>Kopiuj {item.label}</Text>
            <Text style={styles.copyBtnIcon}>📋</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.footerNote}>
        Naciśnij kartę, aby otworzyć aplikację{'\n'}lub przytrzymaj, aby skopiować.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    backgroundColor: COLORS.primary,
    paddingTop: 44,
    paddingBottom: 38,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  headerIconWrap: {
    width: 76, height: 76, borderRadius: 38,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 16, borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  headerIconText: { fontSize: 34 },
  headerTitle: { fontSize: 26, fontWeight: '700', color: COLORS.white, marginBottom: 10 },
  headerSubtitle: { fontSize: 14, color: 'rgba(255,255,255,0.72)', textAlign: 'center', lineHeight: 21 },
  section: { padding: 16, paddingBottom: 4 },
  sectionLabel: {
    fontSize: 13, fontWeight: '700', color: COLORS.secondary,
    marginBottom: 10, marginLeft: 2, textTransform: 'uppercase', letterSpacing: 0.6,
  },
  contactCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.white, borderRadius: 16,
    padding: 16, marginBottom: 12,
    shadowColor: '#000', shadowOpacity: 0.05,
    shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 2,
  },
  contactIconWrap: {
    width: 52, height: 52, borderRadius: 15,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center', justifyContent: 'center', marginRight: 14,
  },
  contactIcon: { fontSize: 24 },
  contactInfo: { flex: 1 },
  contactLabel: {
    fontSize: 12, color: COLORS.secondary, fontWeight: '600',
    marginBottom: 2, textTransform: 'uppercase', letterSpacing: 0.4,
  },
  contactValue: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 3 },
  contactHint: { fontSize: 12, color: COLORS.primary, fontWeight: '500' },
  copyBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORS.white, borderRadius: 12,
    paddingHorizontal: 16, paddingVertical: 14, marginBottom: 10,
    borderWidth: 1.5, borderColor: COLORS.border,
  },
  copyBtnText: { fontSize: 14, fontWeight: '600', color: COLORS.primary },
  copyBtnIcon: { fontSize: 18 },
  footerNote: {
    fontSize: 12, color: COLORS.textLight, textAlign: 'center',
    lineHeight: 18, marginTop: 8, paddingHorizontal: 32,
  },
});
