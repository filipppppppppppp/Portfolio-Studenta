import React from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, Linking,
} from 'react-native';
import { COLORS } from '../theme/colors';
import { deleteProject } from '../storage/storage';

const HABITMATE_ID = '1';

export default function ProjectDetailScreen({ route, navigation }) {
  const { project } = route.params;
  const accentColor = project.imageColor || COLORS.primary;
  const isHabitMate = project.id === HABITMATE_ID;

  const handleDelete = () => {
    Alert.alert('Usuń projekt', `Usunąć "${project.title}"?`, [
      { text: 'Anuluj', style: 'cancel' },
      { text: 'Usuń', style: 'destructive', onPress: async () => {
        await deleteProject(project.id);
        navigation.goBack();
      }},
    ]);
  };

  const handleGitHub = async () => {
    if (!project.github) return;
    const url = project.github.startsWith('http') ? project.github : `https://${project.github}`;
    const ok = await Linking.canOpenURL(url);
    if (ok) await Linking.openURL(url);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
      {/* Banner */}
      <View style={[styles.banner, { backgroundColor: accentColor }]}>
        <View style={styles.bannerIconWrap}>
          <Text style={styles.bannerInitial}>{project.title.charAt(0)}</Text>
        </View>
        <Text style={styles.bannerTitle}>{project.title}</Text>
        <Text style={styles.bannerMeta}>{project.category}  ·  {project.year}</Text>
      </View>

      <View style={styles.body}>
        {/* Status */}
        <View style={styles.statusRow}>
          <View style={[styles.statusDot, {
            backgroundColor: project.status === 'Zakończony' ? COLORS.success : COLORS.primary
          }]} />
          <Text style={styles.statusText}>{project.status}</Text>
        </View>

        {/* HABITMATE launch button */}
        {isHabitMate && (
          <TouchableOpacity
            style={[styles.launchBtn, { backgroundColor: accentColor }]}
            onPress={() => navigation.navigate('HabitMate')}
            activeOpacity={0.85}
          >
            <Text style={styles.launchIcon}>🚀</Text>
            <View>
              <Text style={styles.launchTitle}>Otwórz aplikację HabitMate</Text>
              <Text style={styles.launchSub}>Uruchom interaktywne demo</Text>
            </View>
          </TouchableOpacity>
        )}

        {/* Description */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Opis projektu</Text>
          <Text style={styles.description}>{project.description}</Text>
        </View>

        {/* Technologies */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Technologie</Text>
          <View style={styles.techWrap}>
            {project.technologies.map((tech, i) => (
              <View key={i} style={[styles.techChip, { borderColor: accentColor + '44' }]}>
                <View style={[styles.techDot, { backgroundColor: accentColor }]} />
                <Text style={[styles.techText, { color: accentColor }]}>{tech}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* GitHub */}
        {project.github ? (
          <TouchableOpacity style={styles.card} onPress={handleGitHub} activeOpacity={0.8}>
            <Text style={styles.cardTitle}>Repozytorium</Text>
            <View style={styles.linkRow}>
              <Text style={styles.linkIcon}>🔗</Text>
              <Text style={styles.linkText}>{project.github}</Text>
            </View>
          </TouchableOpacity>
        ) : null}

        {/* Delete */}
        <TouchableOpacity style={styles.deleteBtn} onPress={handleDelete}>
          <Text style={styles.deleteBtnText}>🗑  Usuń projekt</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  banner: { paddingTop: 42, paddingBottom: 38, paddingHorizontal: 24, alignItems: 'center' },
  bannerIconWrap: {
    width: 76, height: 76, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.22)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 14, borderWidth: 2, borderColor: 'rgba(255,255,255,0.38)',
  },
  bannerInitial: { fontSize: 30, fontWeight: '700', color: COLORS.white },
  bannerTitle: { fontSize: 24, fontWeight: '700', color: COLORS.white, marginBottom: 6, textAlign: 'center' },
  bannerMeta: { fontSize: 14, color: 'rgba(255,255,255,0.72)' },
  body: { padding: 16 },
  statusRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: COLORS.white, borderRadius: 12, padding: 14,
    marginBottom: 14, shadowColor: '#000', shadowOpacity: 0.04,
    shadowRadius: 6, elevation: 2,
  },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  statusText: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  launchBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    borderRadius: 16, padding: 18, marginBottom: 14,
    shadowColor: '#5B56D0', shadowOpacity: 0.3,
    shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 4,
  },
  launchIcon: { fontSize: 28 },
  launchTitle: { fontSize: 16, fontWeight: '700', color: '#fff' },
  launchSub: { fontSize: 12, color: 'rgba(255,255,255,0.75)', marginTop: 2 },
  card: {
    backgroundColor: COLORS.white, borderRadius: 16, padding: 18,
    marginBottom: 14, shadowColor: '#000', shadowOpacity: 0.04,
    shadowRadius: 8, elevation: 2,
  },
  cardTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  description: { fontSize: 14, color: COLORS.secondary, lineHeight: 22 },
  techWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  techChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8,
    borderWidth: 1, backgroundColor: COLORS.primaryLight,
  },
  techDot: { width: 7, height: 7, borderRadius: 3.5 },
  techText: { fontSize: 13, fontWeight: '500' },
  linkRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  linkIcon: { fontSize: 18 },
  linkText: { fontSize: 14, color: COLORS.primary, flex: 1 },
  deleteBtn: {
    backgroundColor: COLORS.errorLight, borderRadius: 14,
    padding: 16, alignItems: 'center', marginTop: 4,
    borderWidth: 1, borderColor: COLORS.errorBorder,
  },
  deleteBtnText: { color: COLORS.error, fontWeight: '700', fontSize: 15 },
});
