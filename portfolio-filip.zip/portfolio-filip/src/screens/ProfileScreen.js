import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import { COLORS } from '../theme/colors';

const SKILLS = [
  { name: 'Figma', level: 85 },
  { name: 'UI/UX Design', level: 80 },
  { name: 'Prototypowanie', level: 78 },
  { name: 'User Research', level: 65 },
  { name: 'Design Systems', level: 70 },
  { name: 'iOS HIG', level: 72 },
];

const INFO = [
  { number: '2', label: 'Projekty' },
  { number: '2023', label: 'Rok rozp.' },
  { number: 'iOS', label: 'Spec.' },
];

export default function ProfileScreen() {
  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 32 }}
    >
      <View style={styles.hero}>
        <Image
          source={require('../../assets/avatar.png')}
          style={styles.avatar}
        />
        <Text style={styles.name}>Filip Nocoń</Text>
        <Text style={styles.title}>Student Informatyki</Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>UI/UX Designer</Text>
        </View>
      </View>

      <View style={styles.infoRow}>
        {INFO.map((item, i) => (
          <View key={i} style={styles.infoCard}>
            <Text style={styles.infoNumber}>{item.number}</Text>
            <Text style={styles.infoLabel}>{item.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>O mnie</Text>
        <Text style={styles.bio}>
          Student kierunku Informatyka, pasjonat projektowania aplikacji mobilnych
          i UI/UX design. Interesuję się tworzeniem intuicyjnych interfejsów
          użytkownika zgodnych z wytycznymi Human Interface Guidelines firmy Apple.
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Umiejętności</Text>
        {SKILLS.map((skill, i) => (
          <View key={i} style={styles.skillRow}>
            <View style={styles.skillMeta}>
              <Text style={styles.skillName}>{skill.name}</Text>
              <Text style={styles.skillPct}>{skill.level}%</Text>
            </View>
            <View style={styles.progressBg}>
              <View style={[styles.progressFill, { width: `${skill.level}%` }]} />
            </View>
          </View>
        ))}
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Edukacja</Text>
        <View style={styles.eduRow}>
          <View style={styles.eduDot} />
          <View>
            <Text style={styles.eduTitle}>Informatyka</Text>
            <Text style={styles.eduSub}>Studia inżynierskie · Październik 2023 – obecnie</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  hero: {
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 36,
    paddingHorizontal: 24,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 14,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.6)',
  },
  name: { fontSize: 24, fontWeight: '700', color: COLORS.white, marginBottom: 4 },
  title: { fontSize: 14, color: 'rgba(255,255,255,0.72)', marginBottom: 14 },
  badge: {
    backgroundColor: 'rgba(255,255,255,0.18)',
    paddingHorizontal: 18,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  badgeText: { color: COLORS.white, fontSize: 13, fontWeight: '600' },
  infoRow: { flexDirection: 'row', marginHorizontal: 16, marginTop: 16, gap: 10 },
  infoCard: {
    flex: 1,
    backgroundColor: COLORS.white,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  infoNumber: { fontSize: 20, fontWeight: '700', color: COLORS.primary, marginBottom: 2 },
  infoLabel: { fontSize: 11, color: COLORS.textLight },
  card: {
    backgroundColor: COLORS.white,
    marginHorizontal: 16,
    marginTop: 14,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  cardTitle: { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 14 },
  bio: { fontSize: 14, color: COLORS.secondary, lineHeight: 22 },
  skillRow: { marginBottom: 14 },
  skillMeta: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  skillName: { fontSize: 14, fontWeight: '500', color: COLORS.text },
  skillPct: { fontSize: 13, color: COLORS.secondary },
  progressBg: { height: 7, backgroundColor: COLORS.primaryLight, borderRadius: 4 },
  progressFill: { height: 7, backgroundColor: COLORS.primary, borderRadius: 4 },
  eduRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 14 },
  eduDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: COLORS.primary, marginTop: 3 },
  eduTitle: { fontSize: 15, fontWeight: '600', color: COLORS.text, marginBottom: 2 },
  eduSub: { fontSize: 13, color: COLORS.secondary },
});
