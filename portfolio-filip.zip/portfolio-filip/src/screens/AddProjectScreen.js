import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { COLORS } from '../theme/colors';
import { addProject } from '../storage/storage';

const CATEGORIES = ['Mobile Design', 'UI/UX Design', 'Web Design', 'Inne'];
const STATUSES = ['W trakcie', 'Zakończony'];
const COLOR_OPTIONS = [
  { label: 'Fiolet', value: '#5B56D0' },
  { label: 'Zielony', value: '#1A9E75' },
  { label: 'Różowy', value: '#D4537E' },
  { label: 'Pomarańczowy', value: '#E6A817' },
  { label: 'Granatowy', value: '#3D3A9E' },
];

const INITIAL_FORM = {
  title: '',
  description: '',
  technologies: '',
  category: 'Mobile Design',
  year: new Date().getFullYear().toString(),
  status: 'W trakcie',
  github: '',
  imageColor: '#5B56D0',
};

export default function AddProjectScreen({ navigation }) {
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const updateField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: null }));
  };

  const validate = () => {
    const e = {};
    if (!form.title.trim()) {
      e.title = 'Nazwa projektu jest wymagana';
    } else if (form.title.trim().length < 2) {
      e.title = 'Nazwa musi zawierać co najmniej 2 znaki';
    }

    if (!form.description.trim()) {
      e.description = 'Opis projektu jest wymagany';
    } else if (form.description.trim().length < 20) {
      e.description = 'Opis musi zawierać co najmniej 20 znaków';
    }

    if (!form.technologies.trim()) {
      e.technologies = 'Podaj co najmniej jedną technologię';
    }

    const y = parseInt(form.year, 10);
    if (!form.year.trim() || isNaN(y) || y < 2000 || y > 2100) {
      e.year = 'Podaj poprawny rok (np. 2024)';
    }

    if (form.github.trim() && !form.github.trim().startsWith('http') && !form.github.trim().startsWith('github.com')) {
      e.github = 'Podaj prawidłowy adres URL lub zostaw puste';
    }

    return e;
  };

  const handleSave = async () => {
    const e = validate();
    if (Object.keys(e).length > 0) {
      setErrors(e);
      return;
    }
    setLoading(true);
    const project = {
      ...form,
      title: form.title.trim(),
      description: form.description.trim(),
      technologies: form.technologies
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      github: form.github.trim(),
    };
    await addProject(project);
    setLoading(false);
    Alert.alert('✅ Sukces!', 'Projekt został dodany do portfolio.', [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  /* ---- Sub-components ---- */
  const FieldInput = ({ label, field, placeholder, multiline, keyboardType, required }) => (
    <View style={styles.fieldWrap}>
      <Text style={styles.label}>
        {label}
        {required ? <Text style={styles.required}> *</Text> : null}
      </Text>
      <TextInput
        style={[
          styles.input,
          multiline && styles.inputMulti,
          errors[field] && styles.inputError,
        ]}
        value={form[field]}
        onChangeText={(v) => updateField(field, v)}
        placeholder={placeholder}
        placeholderTextColor={COLORS.textLight}
        multiline={multiline}
        numberOfLines={multiline ? 4 : 1}
        keyboardType={keyboardType || 'default'}
        textAlignVertical={multiline ? 'top' : 'center'}
        autoCorrect={false}
      />
      {errors[field] ? <Text style={styles.errorMsg}>{errors[field]}</Text> : null}
    </View>
  );

  const ChipGroup = ({ label, field, options }) => (
    <View style={styles.fieldWrap}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.chipRow}>
        {options.map((opt) => (
          <TouchableOpacity
            key={opt}
            style={[styles.chip, form[field] === opt && styles.chipActive]}
            onPress={() => updateField(field, opt)}
          >
            <Text style={[styles.chipText, form[field] === opt && styles.chipTextActive]}>
              {opt}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FieldInput label="Nazwa projektu" field="title" placeholder="Np. HabitMate" required />
        <FieldInput
          label="Opis projektu"
          field="description"
          placeholder="Opisz czym jest projekt, co robi i jakie cele realizuje..."
          multiline
          required
        />
        <FieldInput
          label="Technologie (oddziel przecinkami)"
          field="technologies"
          placeholder="Np. Figma, Swift, React Native"
          required
        />
        <FieldInput label="Rok" field="year" placeholder="2024" keyboardType="numeric" />
        <FieldInput
          label="Link do GitHub (opcjonalnie)"
          field="github"
          placeholder="https://github.com/uzytkownik/projekt"
          keyboardType="url"
        />

        <ChipGroup label="Kategoria" field="category" options={CATEGORIES} />
        <ChipGroup label="Status" field="status" options={STATUSES} />

        {/* Color picker */}
        <View style={styles.fieldWrap}>
          <Text style={styles.label}>Kolor akcentu</Text>
          <View style={styles.colorRow}>
            {COLOR_OPTIONS.map((c) => (
              <TouchableOpacity
                key={c.value}
                onPress={() => updateField('imageColor', c.value)}
                style={[
                  styles.colorDot,
                  { backgroundColor: c.value },
                  form.imageColor === c.value && styles.colorDotSelected,
                ]}
              >
                {form.imageColor === c.value && (
                  <Text style={styles.colorCheck}>✓</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Save button */}
        <TouchableOpacity
          style={styles.saveBtn}
          onPress={handleSave}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <ActivityIndicator color={COLORS.white} />
          ) : (
            <Text style={styles.saveBtnText}>Zapisz projekt</Text>
          )}
        </TouchableOpacity>

        <View style={{ height: 48 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scroll: { padding: 16 },

  fieldWrap: { marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  required: { color: COLORS.error },

  input: {
    backgroundColor: COLORS.white,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 15,
    color: COLORS.text,
  },
  inputMulti: { height: 110, paddingTop: 13 },
  inputError: { borderColor: COLORS.error },
  errorMsg: { fontSize: 12, color: COLORS.error, marginTop: 5, marginLeft: 2 },

  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 22,
    backgroundColor: COLORS.white,
    borderWidth: 1.5,
    borderColor: COLORS.border,
  },
  chipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  chipText: { fontSize: 13, color: COLORS.secondary, fontWeight: '500' },
  chipTextActive: { color: COLORS.white, fontWeight: '700' },

  colorRow: { flexDirection: 'row', gap: 14 },
  colorDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorDotSelected: {
    borderWidth: 3,
    borderColor: COLORS.primaryDark,
    transform: [{ scale: 1.15 }],
  },
  colorCheck: { color: COLORS.white, fontSize: 16, fontWeight: '700' },

  saveBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: 14,
    paddingVertical: 17,
    alignItems: 'center',
    marginTop: 6,
    shadowColor: COLORS.primary,
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 5,
  },
  saveBtnText: { color: COLORS.white, fontSize: 16, fontWeight: '700' },
});
