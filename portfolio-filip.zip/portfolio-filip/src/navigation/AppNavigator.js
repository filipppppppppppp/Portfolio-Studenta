import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { COLORS } from '../theme/colors';

import ProfileScreen from '../screens/ProfileScreen';
import ProjectsScreen from '../screens/ProjectsScreen';
import ProjectDetailScreen from '../screens/ProjectDetailScreen';
import AddProjectScreen from '../screens/AddProjectScreen';
import ContactScreen from '../screens/ContactScreen';
import HabitMateApp from '../habitmate/HabitMateApp';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TAB_ICONS = { Profile: '👤', Projects: '📁', Contact: '✉️' };

function ProjectsStack() {
  return (
    <Stack.Navigator screenOptions={{
      headerStyle: { backgroundColor: COLORS.primary },
      headerTintColor: COLORS.white,
      headerTitleStyle: { fontWeight: '700', fontSize: 17 },
    }}>
      <Stack.Screen name="ProjectsList" component={ProjectsScreen} options={{ title: 'Moje Projekty' }} />
      <Stack.Screen name="ProjectDetail" component={ProjectDetailScreen} options={{ title: 'Szczegóły' }} />
      <Stack.Screen name="AddProject" component={AddProjectScreen} options={{ title: 'Nowy Projekt' }} />
      <Stack.Screen
        name="HabitMate"
        component={HabitMateApp}
        options={{ title: 'HabitMate', headerShown: false }}
      />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      tabBarIcon: ({ focused }) => (
        <Text style={{ fontSize: 22, opacity: focused ? 1 : 0.5 }}>
          {TAB_ICONS[route.name]}
        </Text>
      ),
      tabBarStyle: {
        backgroundColor: COLORS.white, borderTopColor: COLORS.border,
        borderTopWidth: 1, height: 64, paddingBottom: 10, paddingTop: 6,
      },
      tabBarActiveTintColor: COLORS.primary,
      tabBarInactiveTintColor: COLORS.textLight,
      tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      headerStyle: { backgroundColor: COLORS.primary },
      headerTintColor: COLORS.white,
      headerTitleStyle: { fontWeight: '700', fontSize: 17 },
    })}>
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profil', headerTitle: 'Moje Portfolio' }} />
      <Tab.Screen name="Projects" component={ProjectsStack} options={{ title: 'Projekty', headerShown: false }} />
      <Tab.Screen name="Contact" component={ContactScreen} options={{ title: 'Kontakt' }} />
    </Tab.Navigator>
  );
}
