import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getHabitStats, toggleCompletion, getTodayCompletions, deleteHabit } from './habitStorage';

export default function HabitDetailScreen({ route, navigation }) {
  const { habit } = route.params;
  const [stats, setStats] = useState(null);
  const [completions, setCompletions] = useState([]);

  useFocusEffect(useCallback(() => {
    let active = true;
    (async () => {
      const [s, c] = await Promise.all([getHabitStats(habit.id), getTodayCompletions()]);
      if (active) { setStats(s); setCompletions(c); }
    })();
    return () => { active = false; };
  }, []));

  const isDone = completions.includes(habit.id);

  const handleToggle = async () => {
    const updated = await toggleCompletion(habit.id);
    setCompletions(updated);
  };

  const handleDelete = () => {
    Alert.alert('Usuń nawyk', `Usunąć "${habit.name}"?`, [
      { text: 'Anuluj', style: 'cancel' },
      { text: 'Usuń', style: 'destructive', onPress: async () => {
        await deleteHabit(habit.id);
        navigation.goBack();
      }},
    ]);
  };

  if (!stats) return <View style={s.centered}><ActivityIndicator size="large" color={habit.color} /></View>;

  return (
    <ScrollView style={s.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
      <View style={[s.banner, { backgroundColor: habit.color }]}>
        <View style={s.iconWrap}>
          <Text style={s.iconText}>{habit.name.charAt(0)}</Text>
        </View>
        <Text style={s.habitName}>{habit.name}</Text>
        <Text style={s.habitMeta}>{habit.frequency} · {habit.category}</Text>
      </View>

      <View style={s.body}>
        <View style={s.statsRow}>
          <View style={s.statCard}>
            <Text style={[s.statNum, { color: habit.color }]}>{stats.streak}</Text>
            <Text style={s.statLabel}>Seria (dni)</Text>
          </View>
          <View style={s.statCard}>
            <Text style={[s.statNum, { color: habit.color }]}>{stats.total}</Text>
            <Text style={s.statLabel}>Łącznie</Text>
          </View>
          <View style={s.statCard}>
            <Text style={[s.statNum, { color: habit.color }]}>{stats.effectiveness}%</Text>
            <Text style={s.statLabel}>Skuteczność</Text>
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.cardTitle}>Ostatnie 7 dni</Text>
          <View style={s.chartRow}>
            {stats.history.map((h, i) => (
              <View key={i} style={s.barWrap}>
                <View style={[s.bar, { backgroundColor: h.done ? habit.color : '#EEEDFE', height: h.done ? 40 : 20 }]} />
                <Text style={[s.barLabel, { color: h.done ? '#6E6BAE' : '#C0BEEA' }]}>{h.day}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.cardTitle}>Historia</Text>
          {stats.history.slice().reverse().map((h, i) => (
            <View key={i} style={s.histRow}>
              <View style={[s.histDot, { backgroundColor: h.done ? habit.color : '#EEEDFE' }]} />
              <Text style={[s.histText, { color: h.done ? '#6E6BAE' : '#C0BEEA' }]}>
                {h.date} — {h.done ? 'Wykonano' : 'Pominięto'}
              </Text>
            </View>
          ))}
        </View>

        <TouchableOpacity
          style={[s.doneBtn, { backgroundColor: isDone ? '#EEEDFE' : habit.color }]}
          onPress={handleToggle}
        >
          <Text style={[s.doneBtnText, { color: isDone ? habit.color : '#fff' }]}>
            {isDone ? '✓ Wykonano dziś' : 'Oznacz jako wykonane'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={s.deleteBtn} onPress={handleDelete}>
          <Text style={s.deleteBtnText}>🗑  Usuń nawyk</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F7F6FF' },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  banner: { paddingTop: 40, paddingBottom: 32, paddingHorizontal: 24, alignItems: 'center' },
  iconWrap: {
    width: 72, height: 72, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 12, borderWidth: 2, borderColor: 'rgba(255,255,255,0.4)',
  },
  iconText: { fontSize: 28, fontWeight: '700', color: '#fff' },
  habitName: { fontSize: 22, fontWeight: '700', color: '#fff', marginBottom: 4 },
  habitMeta: { fontSize: 13, color: 'rgba(255,255,255,0.72)' },
  body: { padding: 16 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  statCard: {
    flex: 1, backgroundColor: '#fff', borderRadius: 14,
    padding: 14, alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 2,
  },
  statNum: { fontSize: 22, fontWeight: '700', marginBottom: 2 },
  statLabel: { fontSize: 11, color: '#9997D3', textAlign: 'center' },
  card: {
    backgroundColor: '#fff', borderRadius: 16,
    padding: 18, marginBottom: 14,
    shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 2,
  },
  cardTitle: { fontSize: 15, fontWeight: '700', color: '#3D3A9E', marginBottom: 14 },
  chartRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 60 },
  barWrap: { alignItems: 'center', flex: 1 },
  bar: { width: 22, borderRadius: 4, marginBottom: 6 },
  barLabel: { fontSize: 10, fontWeight: '500' },
  histRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  histDot: { width: 9, height: 9, borderRadius: 4.5 },
  histText: { fontSize: 13 },
  doneBtn: {
    borderRadius: 14, paddingVertical: 16,
    alignItems: 'center', marginBottom: 12,
    shadowColor: '#5B56D0', shadowOpacity: 0.2,
    shadowRadius: 8, elevation: 3,
  },
  doneBtnText: { fontSize: 16, fontWeight: '700' },
  deleteBtn: {
    backgroundColor: '#FFF0F4', borderRadius: 14,
    padding: 16, alignItems: 'center',
    borderWidth: 1, borderColor: '#FCCDD8',
  },
  deleteBtnText: { color: '#D4537E', fontWeight: '700', fontSize: 15 },
});
