import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getHabits, getTodayCompletions, toggleCompletion } from './habitStorage';

const PRIMARY = '#5B56D0';
const BG = '#F7F6FF';

export default function HabitDashboard({ navigation }) {
  const [habits, setHabits] = useState([]);
  const [completions, setCompletions] = useState([]);
  const [loading, setLoading] = useState(true);

  useFocusEffect(useCallback(() => {
    let active = true;
    (async () => {
      const [h, c] = await Promise.all([getHabits(), getTodayCompletions()]);
      if (active) { setHabits(h); setCompletions(c); setLoading(false); }
    })();
    return () => { active = false; };
  }, []));

  const handleToggle = async (id) => {
    const updated = await toggleCompletion(id);
    setCompletions(updated);
  };

  const done = completions.length;
  const total = habits.length;
  const progress = total > 0 ? done / total : 0;

  const today = new Date().toLocaleDateString('pl-PL', { weekday: 'long', day: 'numeric', month: 'long' });

  if (loading) return <View style={styles.centered}><ActivityIndicator size="large" color={PRIMARY} /></View>;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
      <View style={styles.hero}>
        <Text style={styles.appName}>HabitMate</Text>
        <Text style={styles.date}>{today}</Text>
        <View style={styles.progressRow}>
          <Text style={styles.progressLabel}>Postęp dziś</Text>
          <Text style={styles.progressCount}>{done}/{total}</Text>
        </View>
        <View style={styles.progressBg}>
          <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Do zrobienia dziś</Text>
        {habits.map(habit => {
          const isDone = completions.includes(habit.id);
          return (
            <TouchableOpacity
              key={habit.id}
              style={styles.habitRow}
              onPress={() => handleToggle(habit.id)}
              activeOpacity={0.8}
            >
              <View style={[styles.checkbox, isDone && { backgroundColor: habit.color, borderColor: habit.color }]}>
                {isDone && <Text style={styles.checkmark}>✓</Text>}
              </View>
              <View style={styles.habitInfo}>
                <Text style={[styles.habitName, isDone && styles.habitNameDone]}>{habit.name}</Text>
                <Text style={styles.habitSub}>{habit.subtitle}</Text>
              </View>
              <TouchableOpacity
                style={[styles.detailBtn, { borderColor: habit.color }]}
                onPress={() => navigation.navigate('HabitDetail', { habit })}
              >
                <Text style={[styles.detailBtnText, { color: habit.color }]}>›</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: BG },
  hero: { backgroundColor: PRIMARY, padding: 24, paddingTop: 32, paddingBottom: 28 },
  appName: { fontSize: 28, fontWeight: '700', color: '#fff', marginBottom: 2 },
  date: { fontSize: 13, color: 'rgba(255,255,255,0.72)', marginBottom: 18, textTransform: 'capitalize' },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressLabel: { fontSize: 14, fontWeight: '500', color: 'rgba(255,255,255,0.85)' },
  progressCount: { fontSize: 14, fontWeight: '700', color: '#fff' },
  progressBg: { height: 7, backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 4 },
  progressFill: { height: 7, backgroundColor: '#fff', borderRadius: 4 },
  section: { padding: 16 },
  sectionTitle: { fontSize: 14, fontWeight: '600', color: '#6E6BAE', marginBottom: 12 },
  habitRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#fff', borderRadius: 14,
    padding: 14, marginBottom: 10,
    shadowColor: '#000', shadowOpacity: 0.05,
    shadowRadius: 6, elevation: 2,
  },
  checkbox: {
    width: 26, height: 26, borderRadius: 13,
    borderWidth: 2, borderColor: '#C0BEEA',
    alignItems: 'center', justifyContent: 'center', marginRight: 12,
  },
  checkmark: { color: '#fff', fontSize: 14, fontWeight: '700' },
  habitInfo: { flex: 1 },
  habitName: { fontSize: 15, fontWeight: '600', color: '#3D3A9E' },
  habitNameDone: { textDecorationLine: 'line-through', color: '#9997D3' },
  habitSub: { fontSize: 12, color: '#9997D3', marginTop: 2 },
  detailBtn: {
    width: 28, height: 28, borderRadius: 14,
    borderWidth: 1.5, alignItems: 'center', justifyContent: 'center',
  },
  detailBtnText: { fontSize: 18, fontWeight: '700', lineHeight: 22 },
});
