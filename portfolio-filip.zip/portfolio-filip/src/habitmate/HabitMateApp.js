import React from 'react';
import { Text } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HabitDashboard from './HabitDashboard';
import HabitListScreen from './HabitListScreen';
import HabitDetailScreen from './HabitDetailScreen';
import AddHabitScreen from './AddHabitScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const PRIMARY = '#5B56D0';
const WHITE = '#FFFFFF';

function NawykiStack() {
  return (
    <Stack.Navigator screenOptions={{
      headerStyle: { backgroundColor: PRIMARY },
      headerTintColor: WHITE,
      headerTitleStyle: { fontWeight: '700' },
    }}>
      <Stack.Screen name="HabitList" component={HabitListScreen} options={{ title: 'Moje Nawyki' }} />
      <Stack.Screen name="HabitDetail" component={HabitDetailScreen} options={{ title: 'Szczegóły' }} />
      <Stack.Screen name="AddHabit" component={AddHabitScreen} options={{ title: 'Nowy Nawyk' }} />
    </Stack.Navigator>
  );
}

export default function HabitMateApp() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      tabBarIcon: ({ focused }) => {
        const icons = { Dashboard: '🏠', Nawyki: '📋', Dodaj: '➕' };
        return <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.5 }}>{icons[route.name]}</Text>;
      },
      tabBarStyle: {
        backgroundColor: WHITE, borderTopColor: '#D4D2F0',
        borderTopWidth: 1, height: 60, paddingBottom: 8, paddingTop: 4,
      },
      tabBarActiveTintColor: PRIMARY,
      tabBarInactiveTintColor: '#9997D3',
      tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      headerStyle: { backgroundColor: PRIMARY },
      headerTintColor: WHITE,
      headerTitleStyle: { fontWeight: '700' },
    })}>
      <Tab.Screen name="Dashboard" component={HabitDashboard} options={{ title: 'Dziś', headerTitle: 'HabitMate' }} />
      <Tab.Screen name="Nawyki" component={NawykiStack} options={{ title: 'Nawyki', headerShown: false }} />
      <Tab.Screen name="Dodaj" component={AddHabitScreen} options={{ title: 'Dodaj' }} />
    </Tab.Navigator>
  );
}
