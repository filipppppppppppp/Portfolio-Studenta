import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator, KeyboardAvoidingView, Platform,
} from 'react-native';
import { addHabit } from './habitStorage';

const PRIMARY = '#5B56D0';
const CATEGORIES = ['Zdrowie', 'Edukacja', 'Sport', 'Rozwój', 'Inne'];
const COLORS_OPTS = [
  { value: '#5B56D0' }, { value: '#1A9E75' },
  { value: '#D4537E' }, { value: '#E6A817' }, { value: '#3D3A9E' },
];
const FREQ_OPTS = ['Codziennie', '3x w tyg.', '2x w tyg.', 'Co tydzień'];

const INITIAL = { name: '', subtitle: '', category: 'Zdrowie', frequency: 'Codziennie', color: '#5B56D0' };

export default function AddHabitScreen({ navigation }) {
  const [form, setForm] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const set = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: null }));
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Nazwa nawyku jest wymagana';
    else if (form.name.trim().length < 2) e.name = 'Nazwa musi mieć co najmniej 2 znaki';
    if (!form.subtitle.trim()) e.subtitle = 'Opis / czas jest wymagany';
    return e;
  };

  const handleSave = async () => {
    const e = validate();
    if (Object.keys(e).length > 0) { setErrors(e); return; }
    setLoading(true);
    await addHabit({ ...form, name: form.name.trim(), subtitle: form.subtitle.trim() });
    setLoading(false);
    Alert.alert('✅ Dodano!', 'Nawyk został dodany.', [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={s.container} contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">

        <View style={s.fieldWrap}>
          <Text style={s.label}>Nazwa nawyku <Text style={s.req}>*</Text></Text>
          <TextInput style={[s.input, errors.name && s.inputErr]} value={form.name}
            onChangeText={v => set('name', v)} placeholder="Np. Medytacja" placeholderTextColor="#C0BEEA" />
          {errors.name ? <Text style={s.err}>{errors.name}</Text> : null}
        </View>

        <View style={s.fieldWrap}>
          <Text style={s.label}>Opis / godzina <Text style={s.req}>*</Text></Text>
          <TextInput style={[s.input, errors.subtitle && s.inputErr]} value={form.subtitle}
            onChangeText={v => set('subtitle', v)} placeholder="Np. 10 min rano" placeholderTextColor="#C0BEEA" />
          {errors.subtitle ? <Text style={s.err}>{errors.subtitle}</Text> : null}
        </View>

        <View style={s.fieldWrap}>
          <Text style={s.label}>Kategoria</Text>
          <View style={s.chipRow}>
            {CATEGORIES.map(cat => (
              <TouchableOpacity key={cat}
                style={[s.chip, form.category === cat && s.chipActive]}
                onPress={() => set('category', cat)}>
                <Text style={[s.chipText, form.category === cat && s.chipTextActive]}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={s.fieldWrap}>
          <Text style={s.label}>Częstotliwość</Text>
          <View style={s.chipRow}>
            {FREQ_OPTS.map(f => (
              <TouchableOpacity key={f}
                style={[s.chip, form.frequency === f && s.chipActive]}
                onPress={() => set('frequency', f)}>
                <Text style={[s.chipText, form.frequency === f && s.chipTextActive]}>{f}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={s.fieldWrap}>
          <Text style={s.label}>Kolor</Text>
          <View style={s.colorRow}>
            {COLORS_OPTS.map(c => (
              <TouchableOpacity key={c.value}
                style={[s.colorDot, { backgroundColor: c.value }, form.color === c.value && s.colorSelected]}
                onPress={() => set('color', c.value)}>
                {form.color === c.value && <Text style={s.colorCheck}>✓</Text>}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <TouchableOpacity style={s.saveBtn} onPress={handleSave} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.saveBtnText}>Zapisz nawyk</Text>}
        </TouchableOpacity>
        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F7F6FF' },
  scroll: { padding: 16 },
  fieldWrap: { marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '700', color: '#3D3A9E', marginBottom: 8 },
  req: { color: '#D4537E' },
  input: {
    backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#D4D2F0',
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 13,
    fontSize: 15, color: '#3D3A9E',
  },
  inputErr: { borderColor: '#D4537E' },
  err: { fontSize: 12, color: '#D4537E', marginTop: 5 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 16, paddingVertical: 9, borderRadius: 22,
    backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#D4D2F0',
  },
  chipActive: { backgroundColor: PRIMARY, borderColor: PRIMARY },
  chipText: { fontSize: 13, color: '#6E6BAE', fontWeight: '500' },
  chipTextActive: { color: '#fff', fontWeight: '700' },
  colorRow: { flexDirection: 'row', gap: 14 },
  colorDot: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  colorSelected: { borderWidth: 3, borderColor: '#3D3A9E', transform: [{ scale: 1.15 }] },
  colorCheck: { color: '#fff', fontSize: 16, fontWeight: '700' },
  saveBtn: {
    backgroundColor: PRIMARY, borderRadius: 14, paddingVertical: 17,
    alignItems: 'center', marginTop: 6,
    shadowColor: PRIMARY, shadowOpacity: 0.35, shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 }, elevation: 5,
  },
  saveBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
