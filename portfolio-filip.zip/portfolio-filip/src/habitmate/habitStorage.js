import AsyncStorage from '@react-native-async-storage/async-storage';

const HABITS_KEY = '@habitmate_habits';
const COMPLETIONS_KEY = '@habitmate_completions';

const DEFAULT_HABITS = [
  { id: '1', name: 'Medytacja', subtitle: '10 min rano', category: 'Zdrowie', frequency: 'Codziennie', color: '#5B56D0' },
  { id: '2', name: 'Czytanie', subtitle: '30 minut', category: 'Edukacja', frequency: 'Codziennie', color: '#E6A817' },
  { id: '3', name: 'Bieganie', subtitle: '5 km', category: 'Sport', frequency: '3x w tyg.', color: '#1A9E75' },
  { id: '4', name: 'Woda', subtitle: '2 litry', category: 'Zdrowie', frequency: 'Codziennie', color: '#5B56D0' },
  { id: '5', name: 'Dziennik', subtitle: 'Wieczorem', category: 'Rozwój', frequency: 'Codziennie', color: '#D4537E' },
];

const todayKey = () => new Date().toISOString().split('T')[0];

export const getHabits = async () => {
  try {
    const json = await AsyncStorage.getItem(HABITS_KEY);
    if (json) return JSON.parse(json);
    await AsyncStorage.setItem(HABITS_KEY, JSON.stringify(DEFAULT_HABITS));
    return DEFAULT_HABITS;
  } catch { return DEFAULT_HABITS; }
};

export const saveHabits = async (habits) => {
  try { await AsyncStorage.setItem(HABITS_KEY, JSON.stringify(habits)); } catch {}
};

export const addHabit = async (habit) => {
  const habits = await getHabits();
  const newHabit = { ...habit, id: Date.now().toString() };
  const updated = [...habits, newHabit];
  await saveHabits(updated);
  return updated;
};

export const deleteHabit = async (id) => {
  const habits = await getHabits();
  const updated = habits.filter(h => h.id !== id);
  await saveHabits(updated);
  return updated;
};

export const getTodayCompletions = async () => {
  try {
    const json = await AsyncStorage.getItem(`${COMPLETIONS_KEY}_${todayKey()}`);
    return json ? JSON.parse(json) : [];
  } catch { return []; }
};

export const toggleCompletion = async (habitId) => {
  const completions = await getTodayCompletions();
  const updated = completions.includes(habitId)
    ? completions.filter(id => id !== habitId)
    : [...completions, habitId];
  await AsyncStorage.setItem(`${COMPLETIONS_KEY}_${todayKey()}`, JSON.stringify(updated));
  return updated;
};

export const getHabitStats = async (habitId) => {
  const today = new Date();
  const history = [];
  const dayNames = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So'];
  let streak = 0;
  let total = 0;

  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().split('T')[0];
    const json = await AsyncStorage.getItem(`${COMPLETIONS_KEY}_${key}`);
    const completions = json ? JSON.parse(json) : [];
    const done = completions.includes(habitId);
    if (done) { total++; if (i === 0 || streak > 0) streak++; }
    history.push({ day: dayNames[d.getDay()], done, date: key });
  }

  return { streak, total, effectiveness: Math.round((total / 7) * 100), history };
};
