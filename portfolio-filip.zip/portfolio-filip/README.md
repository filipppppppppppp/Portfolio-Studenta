# 📱 Portfolio App — Filip Nocoń

Natywna aplikacja mobilna stworzona w **React Native / Expo** pełniąca funkcję interaktywnego portfolio studenckiego.

---

## 📸 Prototyp Figma

Makiety wszystkich ekranów dostępne w folderze `/Prototyp`.

---

## 🚀 Instrukcja uruchomienia

### Wymagania
- Node.js 18+
- npm lub yarn
- Expo CLI: `npm install -g expo-cli`
- Aplikacja **Expo Go** na telefonie (iOS / Android)

### Kroki

```bash
# 1. Sklonuj repozytorium
git clone https://github.com/filipnocon/portfolio-app.git
cd portfolio-app

# 2. Zainstaluj zależności
npm install

# 3. Uruchom aplikację
npx expo start
```

Po uruchomieniu zeskanuj kod QR aplikacją **Expo Go**.

---

## ✅ Lista funkcjonalności

| Funkcjonalność | Status |
|---|---|
| Ekran profilu z danymi, opisem i umiejętnościami | ✅ |
| Paski postępu umiejętności | ✅ |
| Lista projektów (FlatList) | ✅ |
| Ekran szczegółów projektu | ✅ |
| Dodawanie nowych projektów (formularz) | ✅ |
| Walidacja formularza | ✅ |
| Usuwanie projektów | ✅ |
| Ekran kontaktowy | ✅ |
| Otwieranie email i GitHub | ✅ |
| Kopiowanie danych kontaktowych | ✅ |
| Nawigacja dolna (Tab Navigator) | ✅ |
| Nawigacja stosowa (Stack Navigator) | ✅ |
| Persystencja danych (AsyncStorage) | ✅ |
| Spersonalizowane dane i kolorystyka | ✅ |

---

## 🛠 Stos technologiczny

| Warstwa | Technologia |
|---|---|
| Framework | React Native + Expo SDK 51 |
| Nawigacja | React Navigation 6 (Bottom Tabs + Native Stack) |
| Persystencja | AsyncStorage |
| Język | JavaScript (ES2022) |
| Linki systemowe | expo-linking |

---

## 📁 Struktura projektu

```
portfolio-filip/
├── App.js                          # Punkt wejścia
├── app.json                        # Konfiguracja Expo
├── package.json
├── src/
│   ├── navigation/
│   │   └── AppNavigator.js         # Konfiguracja nawigacji
│   ├── screens/
│   │   ├── ProfileScreen.js        # Ekran profilu
│   │   ├── ProjectsScreen.js       # Lista projektów
│   │   ├── ProjectDetailScreen.js  # Szczegóły projektu
│   │   ├── AddProjectScreen.js     # Formularz dodawania
│   │   └── ContactScreen.js        # Ekran kontaktowy
│   ├── storage/
│   │   └── storage.js              # AsyncStorage helpers
│   └── theme/
│       └── colors.js               # Paleta kolorów
└── Prototyp/                       # Makiety Figma
```

---

## 🎨 Kolorystyka

Kolor przewodni: **#5B56D0** (fiolet indygo) — spójny z prototypem HabitMate wykonanym w Figmie.

---

## 👤 Autor

**Filip Nocoń**  
Przedmiot: Aplikacje mobilne na iOS  
Rok akademicki: 2025/2026
